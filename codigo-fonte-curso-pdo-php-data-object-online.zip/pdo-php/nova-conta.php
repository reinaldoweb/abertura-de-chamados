<h1>Nova Conta</h1>
<form action="nova-conta-ok.php" method="POST">
<table width="50%" border="1">
<tr>
	<td width="20%">Nome:</td>
	<td width="80%"><input type="text" name="txtNome"></td>
</tr>
<tr>
	
</tr>
<tr>
	<td width="20%">Saldo:</td>
	<td width="80%"><input type="text" name="txtSaldo"></td>
</tr>
<tr>
	
</tr>
<tr>
	<td width="20%"></td>
	<td width="80%"><input type="submit" value="Cadastrar"></td>
</tr>
</form>

